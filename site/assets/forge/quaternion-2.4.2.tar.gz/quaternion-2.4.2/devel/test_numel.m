test_quaternion

q_2x3;
a = q;

q_2x2;
b = q;

[a, b; b, a]

a(2,2) = 1

% a(2,2).z = 1

a.z(2,2) = 1

a.s = a

a.s = a.v

a.w(:,2:end) = b.w

% a.w(:,2:end) = b.w(1,1)

% a(:,2:end).w = b(1,1).w

a(:,2:end) = b

