a = quaternion (2, 3, 4, 5)
b = quaternion (2, -3, 4, 5)

a < b
a > b
a <= b
a >= b

a == b
a != b


c = complex (2, 3)
d = complex (2, -3)

c < d
c > d
c <= d
c >= d

c == d
c != d
