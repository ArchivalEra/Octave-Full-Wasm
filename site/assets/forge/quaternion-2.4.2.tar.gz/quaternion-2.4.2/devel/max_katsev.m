[ax, an] = q2rot (rot2q ([0, 1, 0], 6))

%{
ax =

   0   1   0

an =  2.8584
%}

r = an + pi

% r=6

[ax2, an2] = q2rot (rot2q ([0, 1, 0], an))


[ax, an] = q2rot (rot2q ([0, 1, 0], -pi/2))
