% requires the quaternion package
q = quaternion (eye (3))

% works as expected
a = horzcat (q, eye (3))

% fails because of Octave (version 3.6.4 on Mac OS X)
% results a and b should be exactly the same
size (q)  % somehow Octave thinks q is 1x1 instead of 3x3 on the next line
b = [q, eye(3)]
% error: horizontal dimensions mismatch (1x1 vs 3x3)
% error: called from:
% error:   /Users/lukas/bug_octave.m at line 8, column 3

% fails correctly because of quaternion package
c = [q, eye(1)]
% error: horzcat: cat: dimension mismatch
% error: called from:
% error:   /Users/lukas/quaternion/inst/@quaternion/horzcat.m at line 27, column 5


% This bug seems to be solved in Octave 3.8.1
% http://savannah.gnu.org/bugs/?42234
