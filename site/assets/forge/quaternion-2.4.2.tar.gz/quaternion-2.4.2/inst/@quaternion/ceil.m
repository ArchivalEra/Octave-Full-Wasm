## Copyright (C) 2010-2016   Lukas F. Reichlin
##
## This program is free software: you can redistribute it and/or modify
## it under the terms of the GNU General Public License as published by
## the Free Software Foundation, either version 3 of the License, or
## (at your option) any later version.
##
## This program is distributed in the hope that it will be useful,
## but WITHOUT ANY WARRANTY; without even the implied warranty of
## MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
## GNU General Public License for more details.
##
## You should have received a copy of the GNU General Public License
## along with this program.  If not, see <http://www.gnu.org/licenses/>.

## -*- texinfo -*-
## @deftypefn {Function File} {@var{q} =} ceil (@var{q})
## Round quaternion @var{q} towards positive infinity.
## @end deftypefn

## Author: Lukas Reichlin <lukas.reichlin@gmail.com>
## Created: December 2013
## Version: 0.1

function q = ceil (q)

  if (nargin != 1)
    print_usage ();
  endif
  
  q.w = builtin ("ceil", q.w);
  q.x = builtin ("ceil", q.x);
  q.y = builtin ("ceil", q.y);
  q.z = builtin ("ceil", q.z);

endfunction


%!test
%! q = quaternion (1.2, 2.7, 3.1, 4.9);
%! result = ceil (q);
%! expected = quaternion (2, 3, 4, 5);
%! assert (result == expected);
