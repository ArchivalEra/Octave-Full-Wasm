## Copyright (C) 2010-2016   Lukas F. Reichlin
##
## This program is free software: you can redistribute it and/or modify
## it under the terms of the GNU General Public License as published by
## the Free Software Foundation, either version 3 of the License, or
## (at your option) any later version.
##
## This program is distributed in the hope that it will be useful,
## but WITHOUT ANY WARRANTY; without even the implied warranty of
## MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
## GNU General Public License for more details.
##
## You should have received a copy of the GNU General Public License
## along with this program.  If not, see <http://www.gnu.org/licenses/>.

## -*- texinfo -*-
## @deftypefn {Function File} {@var{bool} =} ispure (@var{q})
## Return true if scalar part of quaternion is zero, otherwise return false.
## @end deftypefn

## Author: Lukas Reichlin <lukas.reichlin@gmail.com>
## Created: May 2010
## Version: 0.1

function bool = ispure (a)

  if (nargin != 1)
    print_usage ();
  endif

  bool = all ((abs (a.w) < eps)(:));

endfunction


%!test
%! q = quaternion (0, 1, 2, 3);
%! assert (ispure (q), true);

%!test
%! q = quaternion (1, 2, 3, 4);
%! assert (ispure (q), false);
