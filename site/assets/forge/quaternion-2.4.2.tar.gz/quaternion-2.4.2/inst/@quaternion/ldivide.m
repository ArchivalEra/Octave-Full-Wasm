## Copyright (C) 2010-2016   Lukas F. Reichlin
##
## This program is free software: you can redistribute it and/or modify
## it under the terms of the GNU General Public License as published by
## the Free Software Foundation, either version 3 of the License, or
## (at your option) any later version.
##
## This program is distributed in the hope that it will be useful,
## but WITHOUT ANY WARRANTY; without even the implied warranty of
## MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
## GNU General Public License for more details.
##
## You should have received a copy of the GNU General Public License
## along with this program.  If not, see <http://www.gnu.org/licenses/>.

## -*- texinfo -*-
## Element-wise left division for quaternions.
## Used by Octave for
##
## @example
## @var{q1} .@backslashchar{} @var{q2}
## @end example

## Author: Lukas Reichlin <lukas.reichlin@gmail.com>
## Created: May 2010
## Version: 0.2

function q = ldivide (a, b)

  if (nargin != 2)
    error ("quaternion: ldivide: this is a binary operator");
  endif

  q = a.^-1 .* b;

endfunction


%!test
%! a = quaternion (2, 0, 0, 0);
%! b = quaternion (4, 0, 0, 0);
%! result = a .\ b;
%! expected = quaternion (2, 0, 0, 0);
%! assert (result == expected);
