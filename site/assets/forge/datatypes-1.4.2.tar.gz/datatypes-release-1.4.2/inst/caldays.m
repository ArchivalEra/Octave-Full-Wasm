## Copyright (C) 2024-2026 Andreas Bertsatos <abertsatos@biol.uoa.gr>
##
## This file is part of the datatypes package for GNU Octave.
##
## This program is free software; you can redistribute it and/or modify it under
## the terms of the GNU General Public License as published by the Free Software
## Foundation; either version 3 of the License, or (at your option) any later
## version.
##
## This program is distributed in the hope that it will be useful, but WITHOUT
## ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
## FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for more
## details.
##
## You should have received a copy of the GNU General Public License along with
## this program; if not, see <http://www.gnu.org/licenses/>.

## -*- texinfo -*-
## @deftypefn {datatypes} {@var{calD} =} caldays (@var{X})
##
## Calendar duration in days.
##
## @code{@var{calD} = caldays (@var{X})} returns a @qcode{calendarDuration}
## array representing calendar days equivalent to the values in @var{X}, which
## must be a numeric array of integer values.
##
## @code{caldays} is also available as a method for @qcode{calendarDuration}
## arrays, in which case it performs the opposite conversion.
##
## @seealso{calendarDuration, calyears, calquarters, calmonths, calweeks,
## calendarDuration.caldays}
## @end deftypefn
function out = caldays (x)
  ## Check input
  if (nargin == 0)
    x = 1;
  elseif (! isnumeric (x))
    error ("caldays: input array must be numeric.");
  elseif (! isreal (x))
    error ("caldays: input array must be real.");
  endif
  xx = x;
  xx(isnan (x)) = 0;
  if (any (fix (xx(:)) != xx(:)))
    error ("caldays: input array must contain only integer values.");
  endif
  out = calendarDuration (0, 0, double (x));
endfunction

%!demo
%! ## `caldays` builds a calendar duration of whole days.  It is one of the
%! ## component builders (`calyears`, `calquarters`, `calmonths`, `calweeks`,
%! ## `caldays`) that you combine by addition to assemble a full span.
%!
%! caldays (10)
%!
%! ## A numeric array builds one duration per element.
%! caldays ([7, 14, 21])

%!test
%! X = magic (3);
%! D = caldays (X);
%! assert_equal (size (D), size (X));
%!test
%! D = caldays ([1, 2, 3]);
%! assert_equal (caldays (D), [1, 2, 3]);
%!test
%! D = caldays ([1, 2, NaN, 4]);
%! assert_equal (caldays (D), [1, 2, NaN, 4]);
%!test
%! D = caldays (int16 (1));
%! assert_equal (caldays (D), 1);
%!test
%! D = caldays ();
%! assert_equal (caldays (D), 1);

%!error<caldays: input array must be numeric.> caldays ("asd");
%!error<caldays: input array must be real.> caldays (1+i);
%!error<caldays: input array must contain only integer values.> ...
%! caldays (1.2);

