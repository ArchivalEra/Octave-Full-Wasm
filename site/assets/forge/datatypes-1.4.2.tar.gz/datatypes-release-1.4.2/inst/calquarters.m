## Copyright (C) 2024-2026 Andreas Bertsatos <abertsatos@biol.uoa.gr>
##
## This file is part of the datatypes package for GNU Octave.
##
## This program is free software; you can redistribute it and/or modify it under
## the terms of the GNU General Public License as published by the Free Software
## Foundation; either version 3 of the License, or (at your option) any later
## version.
##
## This program is distributed in the hope that it will be useful, but WITHOUT
## ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
## FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for more
## details.
##
## You should have received a copy of the GNU General Public License along with
## this program; if not, see <http://www.gnu.org/licenses/>.

## -*- texinfo -*-
## @deftypefn {datatypes} {@var{calD} =} calquarters (@var{X})
##
## Calendar duration in quarters.
##
## @code{@var{calD} = calquarters (@var{X})} returns a @qcode{calendarDuration}
## array representing calendar quarters equivalent to the values in @var{X},
## which must be a numeric array of integer values.
##
## @code{calquarters} is also available as a method for @qcode{calendarDuration}
## arrays, in which case it performs the opposite conversion.
##
## @seealso{calendarDuration, calyears, calmonths, calweeks, caldays,
## calendarDuration.calquarters}
## @end deftypefn
function out = calquarters (x)
  ## Check input
  if (nargin == 0)
    x = 1;
  elseif (! isnumeric (x))
    error ("calquarters: input array must be numeric.");
  elseif (! isreal (x))
    error ("calquarters: input array must be real.");
  endif
  xx = x;
  xx(isnan (x)) = 0;
  if (any (fix (xx(:)) != xx(:)))
    error ("calquarters: input array must contain only integer values.");
  endif
  out = calendarDuration (0, double (x) * 3, 0, 'Format', 'qmdt');
endfunction

%!demo
%! ## `calquarters` builds a calendar duration of whole quarters (each quarter
%! ## is three months).
%!
%! calquarters (3)
%!
%! ## Quarters combine with the other component builders.
%! calquarters (2) + calmonths (1)

%!test
%! X = magic (3);
%! D = calquarters (X);
%! assert_equal (size (D), size (X));
%!test
%! D = calquarters ([1, 2, 3]);
%! assert_equal (calquarters (D), [1, 2, 3]);
%!test
%! D = calquarters ([1, 2, NaN, 4]);
%! assert_equal (calquarters (D), [1, 2, NaN, 4]);
%!test
%! D = calquarters (int16 (1));
%! assert_equal (calquarters (D), 1);
%!test
%! D = calquarters ();
%! assert_equal (calquarters (D), 1);

%!error<calquarters: input array must be numeric.> calquarters ("asd");
%!error<calquarters: input array must be real.> calquarters (1+i);
%!error<calquarters: input array must contain only integer values.> ...
%! calquarters (1.2);

