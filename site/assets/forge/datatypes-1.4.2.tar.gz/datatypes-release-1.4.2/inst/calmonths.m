## Copyright (C) 2024-2026 Andreas Bertsatos <abertsatos@biol.uoa.gr>
##
## This file is part of the datatypes package for GNU Octave.
##
## This program is free software; you can redistribute it and/or modify it under
## the terms of the GNU General Public License as published by the Free Software
## Foundation; either version 3 of the License, or (at your option) any later
## version.
##
## This program is distributed in the hope that it will be useful, but WITHOUT
## ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
## FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for more
## details.
##
## You should have received a copy of the GNU General Public License along with
## this program; if not, see <http://www.gnu.org/licenses/>.

## -*- texinfo -*-
## @deftypefn {datatypes} {@var{calD} =} calmonths (@var{X})
##
## Calendar duration in months.
##
## @code{@var{calD} = calmonths (@var{X})} returns a @qcode{calendarDuration}
## array representing calendar months equivalent to the values in @var{X}, which
## must be a numeric array of integer values.
##
## @code{calmonths} is also available as a method for @qcode{calendarDuration}
## arrays, in which case it performs the opposite conversion.
##
## @seealso{calendarDuration, calyears, calquarters, calweeks, caldays,
## calendarDuration.calmonths}
## @end deftypefn
function out = calmonths (x)
  ## Check input
  if (nargin == 0)
    x = 1;
  elseif (! isnumeric (x))
    error ("calmonths: input array must be numeric.");
  elseif (! isreal (x))
    error ("calmonths: input array must be real.");
  endif
  xx = x;
  xx(isnan (x)) = 0;
  if (any (fix (xx(:)) != xx(:)))
    error ("calmonths: input array must contain only integer values.");
  endif
  out = calendarDuration (0, double (x), 0);
endfunction

%!demo
%! ## `calmonths` builds a calendar duration of whole months.  Twelve or more
%! ## months normalise into years on display.
%!
%! calmonths (5)
%! calmonths (14)

%!test
%! X = magic (3);
%! D = calmonths (X);
%! assert_equal (size (D), size (X));
%!test
%! D = calmonths ([1, 2, 3]);
%! assert_equal (calmonths (D), [1, 2, 3]);
%!test
%! D = calmonths ([1, 2, NaN, 4]);
%! assert_equal (calmonths (D), [1, 2, NaN, 4]);
%!test
%! D = calmonths (int16 (1));
%! assert_equal (calmonths (D), 1);
%!test
%! D = calmonths ();
%! assert_equal (calmonths (D), 1);

%!error<calmonths: input array must be numeric.> calmonths ("asd");
%!error<calmonths: input array must be real.> calmonths (1+i);
%!error<calmonths: input array must contain only integer values.> ...
%! calmonths (1.2);

