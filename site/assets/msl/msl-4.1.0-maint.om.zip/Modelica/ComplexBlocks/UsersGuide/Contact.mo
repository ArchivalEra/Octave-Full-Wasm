within Modelica.ComplexBlocks.UsersGuide;
class Contact "Contact"
  extends Modelica.Icons.Contact;
  annotation (Documentation(info="<html>
<h4>Main authors</h4>

<p>
<strong>Anton Haumer</strong><br>
<a href=\"https://www.haumer.at\">Technical Consulting &amp; Electrical Engineering</a><br>
D-93049 Regensburg, Germany<br>
email: <a href=\"mailto:a.haumer@haumer.at\">a.haumer@haumer.at</a><br>
</p>

<p>
<strong>Dr. Christian Kral</strong><br>
  <a href=\"https://christiankral.net/\">Electric Machines, Drives and Systems</a><br>
  A-1060 Vienna, Austria<br>
  email: <a href=\"mailto:dr.christian.kral@gmail.com\">dr.christian.kral@gmail.com</a>
</p>

<h4>Acknowledgements</h4>

<p>
Copyright &copy; 1998-2025, Modelica Association and contributors
</p>
</html>"));
end Contact;
